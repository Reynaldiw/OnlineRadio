package com.reynaldiwijaya.collage;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import butterknife.BindView;
import butterknife.ButterKnife;

public class DetailKuliahIndonesiaActivity extends AppCompatActivity {

    @BindView(R.id.imgLogo)
    ImageView imgLogo;
    @BindView(R.id.txtTitleKuliah)
    TextView txtTitleKuliah;
    @BindView(R.id.txtDetailKuliah)
    TextView txtDetailKuliah;

    String websiteKuliah;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_kuliah_indonesia);
        ButterKnife.bind(this);

        Toolbar myToolbar = findViewById(R.id.myToolbar);
        setSupportActionBar(myToolbar);

        txtTitleKuliah.setText(getIntent().getStringExtra("nk"));
        txtDetailKuliah.setText(getIntent().getStringExtra("dk"));
        Glide.with(this).load(getIntent().getIntExtra("gk",0)).into(imgLogo);

        websiteKuliah = getIntent().getStringExtra("wk");

        }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    Intent pindah;
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.website:
                pindah = new Intent(Intent.ACTION_VIEW, Uri.parse(websiteKuliah));
                startActivity(pindah);
                break;
            case R.id.prefer:
                pindah = new Intent(this,RecycleCardViewActivity.class);
                startActivity(pindah);
        }
        return super.onOptionsItemSelected(item);
    }
}
