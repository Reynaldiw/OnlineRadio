package com.reynaldiwijaya.collage;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;

import butterknife.BindView;
import butterknife.ButterKnife;

public class RecycleActivity extends AppCompatActivity {

    @BindView(R.id.myRecycleView)
    RecyclerView myRecycleView;

    String [] namaKuliahIT, namaKuliahKedokteran, namaKuliahTeknik, namaKuliahBisnis, detailKuliahIT,detailKuliahKedokteran,detailKuliahTeknik,detailKuliahBisnis,namaKuliahIT2, namaKuliahKedokteran2, namaKuliahTeknik2, namaKuliahBisnis2, detailKuliahIT2,detailKuliahKedokteran2,detailKuliahTeknik2,detailKuliahBisnis2, websiteKuliahIT, websiteKuliahKedokteran, websiteKuliahTeknik, websiteKuliahBisnis, websiteKuliahIT2, websiteKuliahKedokteran2, websiteKuliahTeknik2, websiteKuliahBisnis2;
    int[] gambarKuliahIT,gambarKuliahKedokteran,gambarKuliahTeknik, gambarKuliahBisnis,gambarKuliahIT2,gambarKuliahKedokteran2,gambarKuliahTeknik2, gambarKuliahBisnis2 ;


    Adapter adapterKuliah;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle);
        ButterKnife.bind(this);

        Toolbar myToolbar = findViewById(R.id.myToolbar);
        setSupportActionBar(myToolbar);

        namaKuliahIT = getResources().getStringArray(R.array.nama_kuliah_it);
        namaKuliahKedokteran = getResources().getStringArray(R.array.nama_kuliah_kedokteran);
        namaKuliahTeknik = getResources().getStringArray(R.array.nama_kuliah_teknik);
        namaKuliahBisnis = getResources().getStringArray(R.array.nama_kuliah_bisnis);

        websiteKuliahIT = getResources().getStringArray(R.array.website_kuliah_it);
        websiteKuliahKedokteran = getResources().getStringArray(R.array.website_kuliah_kedokteran);
        websiteKuliahTeknik = getResources().getStringArray(R.array.website_kuliah_teknik);
        websiteKuliahBisnis = getResources().getStringArray(R.array.website_kuliah_bisnis);


        namaKuliahIT2 = getResources().getStringArray(R.array.nama_kuliah_it2);
        namaKuliahKedokteran2 = getResources().getStringArray(R.array.nama_kuliah_kedokteran2);
        namaKuliahTeknik2 = getResources().getStringArray(R.array.nama_kuliah_teknik2);
        namaKuliahBisnis2 = getResources().getStringArray(R.array.nama_kuliah_bisnis2);

        detailKuliahIT = getResources().getStringArray(R.array.detail_kuliah_it);
        detailKuliahKedokteran = getResources().getStringArray(R.array.detail_kuliah_kedokteran);
        detailKuliahTeknik = getResources().getStringArray(R.array.detail_kuliah_teknik);
        detailKuliahBisnis = getResources().getStringArray(R.array.detail_kuliah_bisnis);

        detailKuliahIT2 = getResources().getStringArray(R.array.detail_kuliah_it2);
        detailKuliahKedokteran2 = getResources().getStringArray(R.array.detail_kuliah_kedokteran2);
        detailKuliahTeknik2 = getResources().getStringArray(R.array.detail_kuliah_teknik2);
        detailKuliahBisnis2 = getResources().getStringArray(R.array.detail_kuliah_bisnis2);

        websiteKuliahIT2 = getResources().getStringArray(R.array.website_kuliah_it2);
        websiteKuliahKedokteran2 = getResources().getStringArray(R.array.website_kuliah_kedokteran2);
        websiteKuliahTeknik2 = getResources().getStringArray(R.array.website_kuliah_teknik2);
        websiteKuliahBisnis2 = getResources().getStringArray(R.array.website_kuliah_bisnis2);

        gambarKuliahIT = new int[]{R.drawable.itb,R.drawable.ui, R.drawable.its, R.drawable.ugm,R.drawable.binus};
        gambarKuliahKedokteran = new int[]{R.drawable.ui,R.drawable.unpad, R.drawable.ugm, R.drawable.unair, R.drawable.undip};
        gambarKuliahTeknik = new int[]{R.drawable.itb, R.drawable.ugm, R.drawable.ui, R.drawable.its, R.drawable.undip};
        gambarKuliahBisnis = new int[]{R.drawable.ui, R.drawable.itb, R.drawable.ipmi,R.drawable.ugm, R.drawable.unair};

        gambarKuliahIT2 = new int[]{R.drawable.mit,R.drawable.stanford,R.drawable.oxford,R.drawable.harvard,R.drawable.mellon};
        gambarKuliahKedokteran2 = new int[]{R.drawable.harvard,R.drawable.cambridge,R.drawable.oxford,R.drawable.stanford,R.drawable.john};
        gambarKuliahTeknik2 = new int[]{R.drawable.mit,R.drawable.stanford,R.drawable.cambridge,R.drawable.california,R.drawable.eth};
        gambarKuliahBisnis2 = new int[]{R.drawable.harvardbisnis,R.drawable.insead,R.drawable.hec,R.drawable.stanfordbisnis,R.drawable.london};

        String tanda = getIntent().getStringExtra("tanda");

        if (tanda.equals("it")){
            adapterKuliah = new Adapter(RecycleActivity.this, gambarKuliahIT,namaKuliahIT,detailKuliahIT,websiteKuliahIT);
        }else if (tanda.equals("kedokteran")){
            adapterKuliah = new Adapter(RecycleActivity.this, gambarKuliahKedokteran, namaKuliahKedokteran, detailKuliahKedokteran,websiteKuliahKedokteran);
        }else if (tanda.equals("teknik")){
            adapterKuliah = new Adapter(RecycleActivity.this, gambarKuliahTeknik, namaKuliahTeknik, detailKuliahTeknik,websiteKuliahTeknik);
        }else if (tanda.equals("bisnis")){
            adapterKuliah = new Adapter(RecycleActivity.this, gambarKuliahBisnis, namaKuliahBisnis, detailKuliahBisnis,websiteKuliahBisnis);
        }else if (tanda.equals("it2")){
            adapterKuliah = new Adapter(RecycleActivity.this,gambarKuliahIT2,namaKuliahIT2,detailKuliahIT2,websiteKuliahIT2);
        }else if (tanda.equals("kedokteran2")){
            adapterKuliah = new Adapter(RecycleActivity.this, gambarKuliahKedokteran2,namaKuliahKedokteran2,detailKuliahKedokteran2,websiteKuliahKedokteran2);
        }else if (tanda.equals("teknik2")){
            adapterKuliah = new Adapter(RecycleActivity.this,gambarKuliahTeknik2,namaKuliahTeknik2,detailKuliahTeknik2,websiteKuliahTeknik2);
        }else{
            adapterKuliah = new Adapter(RecycleActivity.this,gambarKuliahBisnis2,namaKuliahBisnis2,detailKuliahBisnis2,websiteKuliahBisnis2);
        }

        myRecycleView.setHasFixedSize(true);
        myRecycleView.setLayoutManager(new LinearLayoutManager(RecycleActivity.this));
        myRecycleView.setAdapter(adapterKuliah);
    }


}
