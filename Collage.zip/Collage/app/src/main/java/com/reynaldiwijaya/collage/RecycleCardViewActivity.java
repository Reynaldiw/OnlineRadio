package com.reynaldiwijaya.collage;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class RecycleCardViewActivity extends AppCompatActivity {

    String[] namaKuliah, remarkKuliah, noTlp;
    int [] gambarKuliah;

    @BindView(R.id.myRecycleView)
    RecyclerView myRecycleView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_card_view);
        ButterKnife.bind(this);

        namaKuliah = getResources().getStringArray(R.array.namaKuliah);
        remarkKuliah = getResources().getStringArray(R.array.remarkKuliah);
        gambarKuliah = new int[]{R.drawable.itb,R.drawable.ui,R.drawable.its,R.drawable.ugm,R.drawable.binus,R.drawable.unpad,R.drawable.unair,R.drawable.undip,R.drawable.ipmi,R.drawable.mit,R.drawable.stanford,R.drawable.oxford,R.drawable.harvard,R.drawable.mellon,R.drawable.cambridge,R.drawable.john,R.drawable.california,R.drawable.eth,R.drawable.harvardbisnis,R.drawable.insead,R.drawable.hec,R.drawable.stanfordbisnis,R.drawable.london};
        noTlp = getResources().getStringArray(R.array.noTlp);

        AdapterCardView adapterCardView = new AdapterCardView(this, namaKuliah, remarkKuliah, gambarKuliah,noTlp);

        myRecycleView.setHasFixedSize(true);
        myRecycleView.setLayoutManager(new LinearLayoutManager(this));
        myRecycleView.setAdapter(adapterCardView);


    }
}
