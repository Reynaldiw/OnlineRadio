package com.reynaldiwijaya.collage;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

public class AdapterCardView extends RecyclerView.Adapter<AdapterCardView.ViewHolder> {
    Context context;
    String[] namaKuliah, remark, noTlp;
    int [] gambarKuliah;

    public AdapterCardView(Context context, String[] namaKuliah, String[] remark, int[] gambarKuliah, String[] noTlp) {
        this.context = context;
        this.namaKuliah = namaKuliah;
        this.remark = remark;
        this.gambarKuliah = gambarKuliah;
        this.noTlp = noTlp;
    }

    @NonNull
    @Override
    public AdapterCardView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_cardview_kuliah,viewGroup,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final AdapterCardView.ViewHolder viewHolder, final int i) {
        viewHolder.namaKuliah.setText(namaKuliah[i]);
        viewHolder.remark.setText(remark[i]);
        Glide.with(context).load(gambarKuliah[i]).into(viewHolder.gambarKuliah);

        viewHolder.btnFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Anda Memfavoritkan " + namaKuliah[i]  , Toast.LENGTH_SHORT).show();
            }
        });

        viewHolder.btnNotlp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah = new Intent(Intent.ACTION_DIAL);
                pindah.setData(Uri.parse("tel:" + noTlp[i]));
                context.startActivity(pindah);
            }
        });

    }

    @Override
    public int getItemCount() {
        return gambarKuliah.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView namaKuliah, remark;
        ImageView gambarKuliah;
        Button btnFavorite, btnNotlp;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            namaKuliah = itemView.findViewById(R.id.txtItemName);
            remark = itemView.findViewById(R.id.txtItemRemarks);
            gambarKuliah = itemView.findViewById(R.id.imgItemPhoto);
            btnFavorite = itemView.findViewById(R.id.btnFavorite);
            btnNotlp = itemView.findViewById(R.id.btnNotlp);
        }
    }
}
