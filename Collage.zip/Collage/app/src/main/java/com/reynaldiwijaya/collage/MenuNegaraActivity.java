package com.reynaldiwijaya.collage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toolbar;

public class MenuNegaraActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_negara);

        android.support.v7.widget.Toolbar myToolbar = findViewById(R.id.myToolbar);
        setSupportActionBar(myToolbar);
    }

    public void btnIndonesia(View view) {
        Intent pindah = new Intent(this, IndonesiaActivity.class);
        startActivity(pindah);
    }

    public void btnLuarNegeri(View view) {
        Intent pindah = new Intent(this, LuarNegeriActivity.class);
        startActivity(pindah);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu2,menu);
        return super.onCreateOptionsMenu(menu);
    }
    Intent pindah;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.profile:
             pindah = new Intent(this, Profile.class);
             startActivity(pindah);
             break;
            case R.id.about:
                pindah = new Intent(this,About.class);
                startActivity(pindah);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
